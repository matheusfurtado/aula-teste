package Principal;

import View.TelaPrincipal;

public class Principal {

    public static void main(String[] args) {
        TelaPrincipal objetotela = new TelaPrincipal();
        objetotela.setVisible(true);
    }
    
}
