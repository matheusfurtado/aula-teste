package DAO;

import Model.Professor;
import java.util.ArrayList;

public class ProfessorDAO {
    public static ArrayList<Professor> MinhaLista = new ArrayList<Professor>();
    
    public static int maiorID() {
        
        int maiorID = 0;
        for (int i = 0; i < MinhaLista.size(); i++) {
            if (MinhaLista.get(i).getId() > maiorID) {
                maiorID = MinhaLista.get(i).getId();
            }
        }
        
        return maiorID;
    }
}
